# -*- coding: utf-8 -*-
"""
Created on Wed Dec  2 22:35:16 2020

@author: Nischal
"""
#%%
# read libraries
from statistics import mean
import numpy as np
from numpy import log10 as log10
import pandas as pd
import matplotlib.pyplot as plt
import sys
from numpy.polynomial.polynomial import polyfit


#%%
filename = 'NCRB_2009.csv'
headers =  ['Category (Col. 1)','States/ UTs (Col. 2)','Category of Complaints Received (Col. 3) - Oral','Category of Complaints Received (Col. 4) - Written','Category of Complaints Received (Col. 5) - Distress call over Phone 100','Category of Complaints Received (Col. 6) - Complaints Initiated Suomoto by Police','Category of Complaints Received (Col. 7) - Total Complaints = Col. (3 to 6)','No. of Cases Registered Under (Col. 8) - IPC','No. of Cases Registered Under (Col. 9) - SLL','No. of Cases Registered Under (Col. 10) - Total = Col. (8+9)']


###############################
#BAR PLOT
data2 = pd.read_csv(filename, header = 0,usecols =[headers[1]])
data = pd.read_csv(filename, header = 0,usecols =[headers[5],headers[6]]) 
total_complaints = data[headers[6]][0:35].values
suomoto_complaints = data[headers[5]][0:35].values
recieved_complaints = total_complaints - suomoto_complaints

log_recieved = log10(recieved_complaints)
log_sunomoto = log10(suomoto_complaints)

plt.figure(1, figsize = (5,5))
N = 35
width = 0.4
ind = np.arange(N)    # the x locations for the groups
p1 = plt.bar(ind-width/2, recieved_complaints,width)
plt.xticks(ind,data2[headers[1]],rotation=90,fontsize=10)
plt.ylabel('Number of complaints')
plt.yscale('log')
plt.title('Complaints received across India 2009')
plt.show()



###############################
#DATA
data = pd.read_csv(filename, header = 0,usecols =[headers[5],headers[6],headers[8]]) 
## SCATTER PLOT
x = data[headers[5]][0:35]
y = data[headers[8]][0:35]
lnx = log10(x.values)
lny = log10(y.values)
plt.figure(2, figsize = (5,5))
plt.scatter(x,y,color='green',label="State/UT")
plt.xlabel("Suomoto complaints")
plt.ylabel("Complaints registered by special laws")
plt.yscale("log")
plt.xscale("log")
plt.legend()
plt.grid()
plt.title('Complaints registered by special laws vs suomoto complaints 2009')
plt.show()

##################################

## BOX PLOT
data = pd.read_csv(filename, header = 0,usecols =[headers[2],headers[3],headers[4],headers[5],headers[8]]) 
boxplotdata = []
outside_registered = []
outside_registered = data[headers[2]][0:35].dropna().tolist()
for i in range(3,5):
    list = data[headers[i]][0:35].dropna().tolist()
    for j in range(0, 35): 
        outside_registered[j] = outside_registered[j] + list[j]
boxplotdata.append(outside_registered)
list = data[headers[5]][0:35].dropna().tolist()
boxplotdata.append(list)
plt.figure(3, figsize = (5,5))
plt.boxplot(boxplotdata)
plt.xticks([1,2],["Received by Police ","Suomoto"])
plt.xlabel("Type of registry")
plt.ylabel("Number of complaints")
plt.yscale("log")
plt.grid()
plt.title('Sumoto and Special law complaints 2009')
plt.show()





